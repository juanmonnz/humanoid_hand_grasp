
import time
import numpy as np
import mujoco
import mujoco.viewer

from sb3_contrib import RecurrentPPO
from rl.grasp_env_v32 import VisualGraspEnvV32 as VisualGraspEnv

MODEL_PATH = "checkpoints/visual_grasp_ppo_v32_finetuned.zip"
XML_PATH = "models/hand.xml"
FPS_DELAY = 0.01


def find_mujoco_objects(env):
    base = env.unwrapped

    model = getattr(base, "model", None)
    data = getattr(base, "data", None)

    if not isinstance(model, mujoco.MjModel):
        raise RuntimeError("Could not find env.model (MuJoCo model).")

    if not isinstance(data, mujoco.MjData):
        raise RuntimeError("Could not find env.data (MuJoCo data).")

    return model, data


def adapt_observation(obs, observation_space):
    result = {}

    for key, space in observation_space.spaces.items():
        if key not in obs:
            print(f"Missing '{key}'; filling with zeros.")
            value = np.zeros(space.shape, dtype=space.dtype)
        else:
            value = np.asarray(obs[key], dtype=space.dtype)

            # Convert HWC image to CHW when required.
            if (
                value.ndim == 3
                and len(space.shape) == 3
                and value.shape[-1] == space.shape[0]
                and value.shape[:2] == space.shape[1:]
            ):
                value = np.transpose(value, (2, 0, 1))

            if value.shape != space.shape:
                raise ValueError(
                    f"{key}: environment shape {value.shape}; "
                    f"model shape {space.shape}"
                )

        result[key] = value

    return result


def main():
    print("Loading trained recurrent PPO...")
    model = RecurrentPPO.load(MODEL_PATH)

    print("Loading environment...")
    env = VisualGraspEnv(
        model_path=XML_PATH,
    )

    obs, info = env.reset()
    mj_model, mj_data = find_mujoco_objects(env)

    print("\nMuJoCo ready")
    print("Bodies:", mj_model.nbody)
    print("Joints:", mj_model.njnt)
    print("Actuators:", mj_model.nu)

    print("\nModel observation shapes:")
    for key, space in model.observation_space.spaces.items():
        print(key, space.shape)

    state = None
    episode_start = np.ones((1,), dtype=bool)
    episode = 1
    step = 0
    total_reward = 0.0

    try:
        with mujoco.viewer.launch_passive(
            mj_model, mj_data
        ) as viewer:

            print("\nLIVE VISUALIZATION RUNNING")
            print("Close the MuJoCo window to stop.")

            while viewer.is_running():

                policy_obs = adapt_observation(
                    obs,
                    model.observation_space
                )

                action, state = model.predict(
                    policy_obs,
                    state=state,
                    episode_start=episode_start,
                    deterministic=True
                )

                obs, reward, terminated, truncated, info = env.step(
                    action
                )

                step += 1
                total_reward += float(reward)

                episode_start = np.array(
                    [terminated or truncated],
                    dtype=bool
                )

                viewer.sync()

                if step % 20 == 0:
                    print(
                        f"Episode {episode} | "
                        f"Step {step} | "
                        f"Actions {np.round(action, 2)} | "
                        f"Reward {float(reward):.3f} | "
                        f"Success {info.get('success', False)}"
                    )

                if terminated or truncated:
                    print(
                        f"\nEpisode {episode} finished | "
                        f"Reward {total_reward:.2f} | "
                        f"Success {info.get('success', False)}"
                    )

                    obs, info = env.reset()
                    state = None
                    episode_start = np.ones((1,), dtype=bool)

                    episode += 1
                    step = 0
                    total_reward = 0.0

                time.sleep(FPS_DELAY)

    finally:
        env.close()
        print("Visualization stopped.")


if __name__ == "__main__":
    main()
