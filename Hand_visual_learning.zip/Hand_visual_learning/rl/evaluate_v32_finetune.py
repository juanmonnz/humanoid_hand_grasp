"""Evaluate the V3 policy fine-tuned with the V3.2 reward; save an MP4."""
from __future__ import annotations
from pathlib import Path
import numpy as np
import cv2
from sb3_contrib import RecurrentPPO
from rl.grasp_env_v32 import VisualGraspEnvV32

ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = ROOT / "checkpoints" / "visual_grasp_ppo_v32_finetuned.zip"
XML_PATH = ROOT / "models" / "hand.xml"
VIDEO_PATH = ROOT / "results" / "visual_grasp_v32_finetuned.mp4"


def main():
    if not MODEL_PATH.is_file():
        raise FileNotFoundError(
            f"Model not found: {MODEL_PATH}. Run `python -m rl.train_v32_finetune` first."
        )
    env = VisualGraspEnvV32(
        model_path=str(XML_PATH), frame_skip=10,
        max_episode_steps=300, image_size=84
    )
    model = RecurrentPPO.load(str(MODEL_PATH), device="auto")
    VIDEO_PATH.parent.mkdir(parents=True, exist_ok=True)
    writer = cv2.VideoWriter(
        str(VIDEO_PATH), cv2.VideoWriter_fourcc(*"mp4v"), 25,
        (env.image_size, env.image_size)
    )
    if not writer.isOpened():
        env.close()
        raise RuntimeError("Could not create evaluation video using mp4v codec.")

    obs, _ = env.reset(seed=11)
    state = None
    episode_start = np.ones((1,), dtype=bool)
    total_reward = 0.0
    info = {}
    try:
        for step in range(env.max_episode_steps):
            action, state = model.predict(
                obs, state=state, episode_start=episode_start,
                deterministic=True
            )
            obs, reward, terminated, truncated, info = env.step(action)
            episode_start = np.array([terminated or truncated], dtype=bool)
            total_reward += float(reward)
            writer.write(cv2.cvtColor(obs["rgb"], cv2.COLOR_RGB2BGR))
            if step % 25 == 0 or terminated or truncated:
                print(
                    f"step={step:03d} action={np.round(action, 2).tolist()} "
                    f"contacts={info['contact_fingers']} "
                    f"stable={info['stable_steps']} "
                    f"speed={info['object_speed']:.4f} "
                    f"displacement={info['object_displacement']:.4f} "
                    f"reward={float(reward):+.3f}"
                )
            if terminated or truncated:
                break
        print(f"\nEpisode reward: {total_reward:.3f}")
        print(f"Success: {bool(info.get('success', False))}")
        print(f"Video: {VIDEO_PATH}")
    finally:
        writer.release()
        env.close()


if __name__ == "__main__":
    main()
