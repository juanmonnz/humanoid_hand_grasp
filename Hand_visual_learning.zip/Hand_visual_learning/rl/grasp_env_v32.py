"""Visual-only MuJoCo grasping environment, version 3.

Policy observations contain RGB and depth images only. Joint state, object pose,
velocity, and contacts are used exclusively by the environment reward/evaluator.
"""
from __future__ import annotations

from typing import Dict, List, Set, Tuple
import os
import re

import gymnasium as gym
from gymnasium import spaces
import mujoco
import numpy as np


FINGERS = ("thumb", "index", "middle", "ring", "little")
JOINT_PART_ORDER = {"mcp": 0, "pip": 1, "dip": 2}
CURL_RATIOS = {"mcp": 1.00, "pip": 0.90, "dip": 0.80}


def _name(model, object_type, idx: int) -> str:
    value = mujoco.mj_id2name(model, object_type, int(idx))
    return value or f"unnamed_{int(idx)}"


class VisualGraspEnvV32(gym.Env):
    """Learn a stable stationary grasp using only rendered RGB/depth observations."""

    metadata = {"render_modes": ["rgb_array"], "render_fps": 25}

    def __init__(
        self,
        model_path: str = "models/hand.xml",
        frame_skip: int = 10,
        max_episode_steps: int = 250,
        image_size: int = 84,
        render_mode=None,
        thumb_max_speed: float = 0.80,
    ):
        super().__init__()
        if not os.path.isfile(model_path):
            raise FileNotFoundError(
                f"MuJoCo XML not found: {model_path}. Run from the project root."
            )

        self.model_path = model_path
        self.model = mujoco.MjModel.from_xml_path(model_path)
        self.data = mujoco.MjData(self.model)
        self.frame_skip = int(frame_skip)
        self.max_episode_steps = int(max_episode_steps)
        self.image_size = int(image_size)
        self.render_mode = render_mode

        # The camera must exist in the user's existing model.
        camera_names = [
            _name(self.model, mujoco.mjtObj.mjOBJ_CAMERA, i)
            for i in range(self.model.ncam)
        ]
        if not camera_names:
            raise ValueError("hand.xml needs at least one camera for visual-only policy input.")
        self.camera_name = "overview" if "overview" in camera_names else camera_names[0]
        self.renderer = mujoco.Renderer(
            self.model, height=self.image_size, width=self.image_size
        )

        self._discover_object()
        self._discover_fingers_and_actuators()

        # The thumb is rate-limited in normalized closure space. Its speed is
        # expressed as MCP radians/second, so the same setting works if the XML
        # changes the thumb's MCP range.
        self.thumb_max_speed = float(thumb_max_speed)
        if not np.isfinite(self.thumb_max_speed) or self.thumb_max_speed <= 0.0:
            raise ValueError("thumb_max_speed must be a positive finite value")
        thumb_mcp = next(
            ((joint_id, part) for _, joint_id, part in self.finger_actuators["thumb"]
             if part == "mcp"),
            None,
        )
        if thumb_mcp is None:
            raise ValueError("The thumb needs an actuated MCP joint for rate-limited closure")
        thumb_mcp_joint_id = thumb_mcp[0]
        thumb_lo, thumb_hi = map(float, self.model.jnt_range[thumb_mcp_joint_id])
        self.thumb_mcp_span = max(thumb_hi - thumb_lo, 1e-6)
        self.thumb_command = 0.0
        self.thumb_contact_hold = False
        self._thumb_opening_request = False

        # Both channels are images. There are deliberately no joint/contact/state inputs.
        self.observation_space = spaces.Dict(
            {
                "rgb": spaces.Box(0, 255, (self.image_size, self.image_size, 3), dtype=np.uint8),
                "depth": spaces.Box(0, 255, (self.image_size, self.image_size, 1), dtype=np.uint8),
            }
        )
        self.action_space = spaces.Box(
            low=np.zeros(5, dtype=np.float32),
            high=np.ones(5, dtype=np.float32),
            dtype=np.float32,
        )

        self.episode_count = 0
        self.step_count = 0
        self.stable_steps = 0
        self.success = False
        self.ever_contacted: Set[str] = set()
        self.last_contacts: Set[str] = set()
        self.last_contact_count = 0
        self.last_action = np.zeros(5, dtype=np.float32)
        self._last_distances = {finger: 0.20 for finger in FINGERS}
        self._last_potential = 0.0
        self._object_start = self.data.xpos[self.object_body_id].copy()

        # Verify the target is actually reachable by a free body and every finger
        # has at least one actuated joint before the RL run starts.
        discovered = {f: len(self.finger_actuators[f]) for f in FINGERS}
        missing = [f for f, count in discovered.items() if count == 0]
        if missing:
            raise ValueError(
                "Could not map actuators for: " + ", ".join(missing)
                + ". Joint names must contain thumb/index/middle/ring/little and "
                  "mcp/pip/dip. Found joints: " + ", ".join(self.joint_names)
            )

    def _discover_object(self):
        free_type = int(mujoco.mjtJoint.mjJNT_FREE)
        free_ids = [i for i in range(self.model.njnt) if int(self.model.jnt_type[i]) == free_type]
        if not free_ids:
            raise ValueError("hand.xml needs a free joint on the grasp target object.")

        preferred = ("block", "cube", "object", "target", "test")
        chosen = None
        for joint_id in free_ids:
            body_id = int(self.model.jnt_bodyid[joint_id])
            body_name = _name(self.model, mujoco.mjtObj.mjOBJ_BODY, body_id).lower()
            joint_name = _name(self.model, mujoco.mjtObj.mjOBJ_JOINT, joint_id).lower()
            if any(term in body_name or term in joint_name for term in preferred):
                chosen = joint_id
                break
        if chosen is None:
            if len(free_ids) != 1:
                names = [
                    _name(self.model, mujoco.mjtObj.mjOBJ_BODY, int(self.model.jnt_bodyid[j]))
                    for j in free_ids
                ]
                raise ValueError(f"Multiple free bodies found; cannot identify target: {names}")
            chosen = free_ids[0]

        self.object_joint_id = int(chosen)
        self.object_body_id = int(self.model.jnt_bodyid[chosen])
        self.object_qpos_adr = int(self.model.jnt_qposadr[chosen])
        self.object_dof_adr = int(self.model.jnt_dofadr[chosen])
        self.object_body_name = _name(
            self.model, mujoco.mjtObj.mjOBJ_BODY, self.object_body_id
        )

        def descendant(body_id: int, root_id: int) -> bool:
            current = int(body_id)
            while current > 0:
                if current == root_id:
                    return True
                current = int(self.model.body_parentid[current])
            return current == root_id

        self._is_descendant = descendant
        self.object_geom_ids = [
            g for g in range(self.model.ngeom)
            if descendant(int(self.model.geom_bodyid[g]), self.object_body_id)
        ]
        if not self.object_geom_ids:
            raise ValueError(f"Target body '{self.object_body_name}' has no collision geometry.")

        mujoco.mj_resetData(self.model, self.data)
        mujoco.mj_forward(self.model, self.data)
        self.base_object_pose = self.data.qpos[
            self.object_qpos_adr : self.object_qpos_adr + 7
        ].copy()
        self.base_object_pos = self.base_object_pose[:3].copy()

    def _discover_fingers_and_actuators(self):
        self.joint_names = [
            _name(self.model, mujoco.mjtObj.mjOBJ_JOINT, i)
            for i in range(self.model.njnt)
        ]
        self.finger_joint_ids: Dict[str, List[int]] = {f: [] for f in FINGERS}
        for joint_id, name in enumerate(self.joint_names):
            lower = name.lower()
            if int(self.model.jnt_type[joint_id]) != int(mujoco.mjtJoint.mjJNT_HINGE):
                continue
            for finger in FINGERS:
                if finger in lower and any(part in lower for part in JOINT_PART_ORDER):
                    self.finger_joint_ids[finger].append(joint_id)
                    break

        # Build actuator lookup from MuJoCo transmissions, not assumed actuator names.
        self.finger_actuators: Dict[str, List[Tuple[int, int, str]]] = {
            f: [] for f in FINGERS
        }
        for finger in FINGERS:
            joints = sorted(
                self.finger_joint_ids[finger],
                key=lambda jid: min(
                    (order for part, order in JOINT_PART_ORDER.items()
                     if part in self.joint_names[jid].lower()),
                    default=99,
                ),
            )
            for joint_id in joints:
                part = next(
                    (part for part in JOINT_PART_ORDER if part in self.joint_names[joint_id].lower()),
                    "mcp",
                )
                for actuator_id in range(self.model.nu):
                    if int(self.model.actuator_trnid[actuator_id, 0]) == joint_id:
                        self.finger_actuators[finger].append((actuator_id, joint_id, part))

        # Identify every geom belonging to any segment body in each finger chain.
        self.finger_geom_ids: Dict[str, Set[int]] = {f: set() for f in FINGERS}
        for finger in FINGERS:
            finger_bodies = {
                int(self.model.jnt_bodyid[j]) for j in self.finger_joint_ids[finger]
            }
            for geom_id in range(self.model.ngeom):
                body_id = int(self.model.geom_bodyid[geom_id])
                if any(self._is_descendant(body_id, root) for root in finger_bodies):
                    if geom_id not in self.object_geom_ids:
                        self.finger_geom_ids[finger].add(geom_id)

            # Name-based fallback for XMLs whose distal geometry is not nested below
            # the joint body for some reason.
            if not self.finger_geom_ids[finger]:
                for geom_id in range(self.model.ngeom):
                    geom_name = _name(self.model, mujoco.mjtObj.mjOBJ_GEOM, geom_id).lower()
                    body_name = _name(
                        self.model, mujoco.mjtObj.mjOBJ_BODY,
                        int(self.model.geom_bodyid[geom_id])
                    ).lower()
                    if finger in geom_name or finger in body_name:
                        if geom_id not in self.object_geom_ids:
                            self.finger_geom_ids[finger].add(geom_id)

    def _set_action(self, action: np.ndarray):
        action = np.asarray(action, dtype=np.float32).reshape(5)
        action = np.clip(action, 0.0, 1.0)

        # Thumb control has two protections:
        # 1) Rate-limit its requested closure so PPO cannot snap it shut in one step.
        # 2) After thumb-object contact, hold the thumb while the other fingers
        #    establish at least two contacts. An explicit opening action always
        #    remains available so the policy can recover from a bad grasp.
        requested_thumb = float(action[0])
        self._thumb_opening_request = requested_thumb < (self.thumb_command - 1e-4)
        if self.thumb_contact_hold and not self._thumb_opening_request:
            effective_thumb = self.thumb_command
        else:
            if self._thumb_opening_request:
                self.thumb_contact_hold = False
            env_dt = float(self.model.opt.timestep) * self.frame_skip
            max_closure_change = (
                self.thumb_max_speed * env_dt / self.thumb_mcp_span
            )
            change = float(np.clip(
                requested_thumb - self.thumb_command,
                -max_closure_change,
                max_closure_change,
            ))
            self.thumb_command = float(np.clip(
                self.thumb_command + change, 0.0, 1.0
            ))
            effective_thumb = self.thumb_command

        for finger_index, finger in enumerate(FINGERS):
            closure = effective_thumb if finger == "thumb" else float(action[finger_index])
            for actuator_id, joint_id, part in self.finger_actuators[finger]:
                lo, hi = map(float, self.model.jnt_range[joint_id])
                # The hand XML already defines joint limits; use a conservative
                # coupled curl so distal joints do not over-fold relative to MCP.
                ratio = CURL_RATIOS.get(part, 1.0)
                target = lo + (hi - lo) * closure * ratio
                if bool(self.model.actuator_ctrllimited[actuator_id]):
                    ctrl_lo, ctrl_hi = map(float, self.model.actuator_ctrlrange[actuator_id])
                    target = float(np.clip(target, ctrl_lo, ctrl_hi))
                self.data.ctrl[actuator_id] = target
        self.last_action = action.copy()

    def _geom_distance(self, geom_a: int, geom_b: int) -> float:
        # Exact signed surface distance where exposed by the installed MuJoCo API.
        if hasattr(mujoco, "mj_geomDistance"):
            fromto = np.zeros(6, dtype=np.float64)
            try:
                value = float(mujoco.mj_geomDistance(
                    self.model, self.data, int(geom_a), int(geom_b), 0.20, fromto
                ))
                if np.isfinite(value) and value < 1e5:
                    return max(0.0, value)
            except (TypeError, ValueError, RuntimeError):
                pass

        # Safe fallback: center distance minus MuJoCo bounding radii.
        center_distance = float(np.linalg.norm(
            self.data.geom_xpos[geom_a] - self.data.geom_xpos[geom_b]
        ))
        radius_a = float(self.model.geom_rbound[geom_a])
        radius_b = float(self.model.geom_rbound[geom_b])
        return max(0.0, center_distance - radius_a - radius_b)

    def _finger_distances(self) -> Dict[str, float]:
        distances = {}
        for finger in FINGERS:
            finger_geoms = self.finger_geom_ids[finger]
            if not finger_geoms:
                distances[finger] = 0.20
                continue
            best = 0.20
            for fg in finger_geoms:
                for og in self.object_geom_ids:
                    best = min(best, self._geom_distance(fg, og))
                    if best <= 1e-5:
                        break
                if best <= 1e-5:
                    break
            distances[finger] = float(best)
        return distances

    def _contact_fingers(self) -> Set[str]:
        object_geoms = set(self.object_geom_ids)
        contacts: Set[str] = set()
        for index in range(self.data.ncon):
            contact = self.data.contact[index]
            if float(contact.dist) > 0.002:
                continue
            g1, g2 = int(contact.geom1), int(contact.geom2)
            if g1 in object_geoms:
                hand_geom = g2
            elif g2 in object_geoms:
                hand_geom = g1
            else:
                continue
            for finger in FINGERS:
                if hand_geom in self.finger_geom_ids[finger]:
                    contacts.add(finger)
        return contacts

    def _object_velocity(self):
        v = self.data.qvel[self.object_dof_adr : self.object_dof_adr + 6]
        return float(np.linalg.norm(v[:3])), float(np.linalg.norm(v[3:6]))

    def _render_observation(self):
        self.renderer.update_scene(self.data, camera=self.camera_name)
        rgb = self.renderer.render()
        rgb = np.asarray(rgb, dtype=np.uint8)

        depth = np.zeros((self.image_size, self.image_size), dtype=np.uint8)
        try:
            self.renderer.enable_depth_rendering()
            self.renderer.update_scene(self.data, camera=self.camera_name)
            raw_depth = np.asarray(self.renderer.render(), dtype=np.float32)
            self.renderer.disable_depth_rendering()
            # MuJoCo's depth render is metric. One metre is enough for this tabletop
            # workspace and keeps the scale fixed across frames/episodes.
            depth = (np.clip(np.nan_to_num(raw_depth, nan=1.0, posinf=1.0), 0.0, 1.0)
                     * 255.0).astype(np.uint8)
        except Exception:
            try:
                self.renderer.disable_depth_rendering()
            except Exception:
                pass

        return {
            "rgb": rgb.copy(),
            "depth": depth[..., None].copy(),
        }

    def _potential(self, distances: Dict[str, float]) -> float:
        # Dense, per-digit visual-task shaping. The thumb gets modest extra weight
        # because it must oppose the other fingers, but all five digits matter.
        weights = {"thumb": 1.7, "index": 1.0, "middle": 1.0,
                   "ring": 1.0, "little": 1.0}
        return float(sum(
            weights[finger] * np.exp(-min(float(distances[finger]), 0.20) / 0.055)
            for finger in FINGERS
        ))

    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)
        mujoco.mj_resetData(self.model, self.data)
        self.episode_count += 1
        self.step_count = 0
        self.stable_steps = 0
        self.success = False
        self.ever_contacted.clear()
        self.last_contacts.clear()
        self.last_contact_count = 0
        self.last_action[:] = 0.0
        self.thumb_command = 0.0
        self.thumb_contact_hold = False
        self._thumb_opening_request = False

        # Curriculum: begin almost deterministic, then expand only within a small
        # tabletop region around the original reachable target pose.
        level = min(1.0, max(0.0, (self.episode_count - 1) / 100.0))
        xy_span = 0.001 + 0.009 * level
        yaw_span = np.deg2rad(12.0) * level
        qadr = self.object_qpos_adr
        self.data.qpos[qadr : qadr + 3] = self.base_object_pos + np.array([
            self.np_random.uniform(-xy_span, xy_span),
            self.np_random.uniform(-xy_span, xy_span),
            0.0,
        ])
        yaw = float(self.np_random.uniform(-yaw_span, yaw_span))
        # MuJoCo free-joint quaternion order is w, x, y, z.
        self.data.qpos[qadr + 3 : qadr + 7] = np.array([
            np.cos(yaw / 2.0), 0.0, 0.0, np.sin(yaw / 2.0)
        ])
        self.data.qvel[self.object_dof_adr : self.object_dof_adr + 6] = 0.0
        self.data.ctrl[:] = 0.0
        mujoco.mj_forward(self.model, self.data)
        self._object_start = self.data.xpos[self.object_body_id].copy()
        self._last_distances = self._finger_distances()
        self._last_potential = self._potential(self._last_distances)
        return self._render_observation(), {
            "object_body": self.object_body_name,
            "curriculum_level": level,
        }

    def step(self, action):
        action = np.asarray(action, dtype=np.float32).reshape(5)
        action = np.clip(action, 0.0, 1.0)
        previous_action = self.last_action.copy()
        self._set_action(action)
        for _ in range(self.frame_skip):
            mujoco.mj_step(self.model, self.data)

        self.step_count += 1
        contacts = self._contact_fingers()
        contact_count = len(contacts)
        self.last_contacts = set(contacts)
        self.last_contact_count = contact_count

        distances = self._finger_distances()
        potential = self._potential(distances)

        # Reward progress toward the object AND remaining in useful proximity.
        # V3.1 only rewarded changes in proximity and then penalized three
        # non-thumb contacts every timestep. That made avoiding contact an easy
        # strategy. This version never punishes useful partial contact.
        potential_delta = float(np.clip(
            potential - self._last_potential, -0.65, 0.65
        ))
        reward = 0.70 * potential_delta + 0.075 * potential
        self._last_potential = potential
        self._last_distances = distances

        new_contacts = contacts - self.ever_contacted
        reward += 1.50 * len(new_contacts)
        self.ever_contacted.update(contacts)

        thumb_present = "thumb" in contacts
        other_count = sum(f in contacts for f in FINGERS if f != "thumb")

        # Latch a pause at first thumb contact. Keep the thumb at that command
        # while the other digits move; resume only after at least two other digits
        # make contact, or immediately when the policy explicitly asks to open.
        if thumb_present and other_count < 2 and not self._thumb_opening_request:
            self.thumb_contact_hold = True
        else:
            self.thumb_contact_hold = False

        # Contact rewards are deliberately staged. Non-thumb contacts are useful
        # discoveries, not failures; thumb opposition earns the larger reward.
        reward += 0.10 * contact_count
        if thumb_present and other_count >= 2:
            reward += 1.15
        elif thumb_present and other_count == 1:
            reward += 0.40
        elif other_count >= 2:
            reward += 0.12 * other_count

        linear_speed, angular_speed = self._object_velocity()
        object_position = self.data.xpos[self.object_body_id].copy()
        object_delta = object_position - self._object_start
        displacement = float(np.linalg.norm(object_delta))
        horizontal_displacement = float(np.linalg.norm(object_delta[:2]))
        lift_height = float(object_delta[2])

        # A successful lift is intentional vertical movement. Penalize sideways
        # pushing, not the height gained while raising the object.
        if contact_count:
            reward -= 0.15 * min(linear_speed, 1.0)
            reward -= 0.04 * min(angular_speed, 2.0)
            reward -= 0.35 * min(horizontal_displacement, 0.10)

        coordinated = thumb_present and other_count >= 2
        # Require a real lift of at least 1 cm and a reasonably centered object,
        # then require the grasp to remain stable for 30 consecutive env steps.
        stable_configuration = (
            coordinated
            and lift_height >= 0.010
            and linear_speed < 0.080
            and angular_speed < 1.00
            and horizontal_displacement < 0.060
        )
        if stable_configuration:
            self.stable_steps += 1
            reward += 1.50
        else:
            self.stable_steps = 0
            if coordinated:
                # Keep the policy interested in discovering opposition while the
                # free object is settling, instead of requiring instant stability.
                reward += 0.45

        # Small neutral-closing prior helps prevent the all-open local optimum;
        # proximity/contact rewards still dominate the objective.
        reward += 0.035 * float(np.mean(action))
        reward -= 0.004 * float(np.mean(np.abs(action - previous_action)))

        terminated = False
        truncated = self.step_count >= self.max_episode_steps
        success = self.stable_steps >= 30
        if success:
            reward += 40.0
            terminated = True
            self.success = True

        object_fell = object_position[2] < (self.base_object_pos[2] - 0.045)
        object_pushed_away = horizontal_displacement > 0.10
        if not success and (object_fell or object_pushed_away):
            reward -= 15.0
            terminated = True

        if truncated and not success:
            reward -= 3.0

        info = {
            "is_success": bool(success),
            "contact_count": contact_count,
            "contact_fingers": tuple(sorted(contacts)),
            "other_finger_count": int(other_count),
            "thumb_contact": bool(thumb_present),
            "thumb_command": float(self.thumb_command),
            "thumb_requested_closure": float(action[0]),
            "thumb_contact_hold": bool(self.thumb_contact_hold),
            "thumb_max_speed_rad_s": float(self.thumb_max_speed),
            "coordinated_contact": bool(coordinated),
            "stable_steps": int(self.stable_steps),
            "object_speed": linear_speed,
            "object_angular_speed": angular_speed,
            "object_displacement": displacement,
            "object_horizontal_displacement": horizontal_displacement,
            "object_lift_height": lift_height,
            "finger_distances": distances,
            "success": bool(success),
        }
        return self._render_observation(), float(reward), terminated, truncated, info

    def render(self):
        return self._render_observation()["rgb"]

    def close(self):
        if getattr(self, "renderer", None) is not None:
            self.renderer.close()
            self.renderer = None


# Backward-compatible name used by rl.live_visualize and older scripts.
VisualGraspEnv = VisualGraspEnvV32
