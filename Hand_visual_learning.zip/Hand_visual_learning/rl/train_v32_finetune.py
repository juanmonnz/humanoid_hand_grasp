"""Fine-tune the multi-finger V3 policy using the corrected V3.2 reward.

Requires existing checkpoints/visual_grasp_ppo_v3.zip and rl/grasp_env_v32.py.
The V3 policy is used because it previously demonstrated contacts on several
fingers; the collapsed V3.2-from-scratch checkpoint is intentionally ignored.
Policy observations remain RGB/depth only.
"""
from __future__ import annotations
from pathlib import Path

from sb3_contrib import RecurrentPPO
from stable_baselines3.common.callbacks import CheckpointCallback
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.vec_env import DummyVecEnv, VecMonitor

from rl.grasp_env_v32 import VisualGraspEnvV32

ROOT = Path(__file__).resolve().parents[1]
XML_PATH = ROOT / "models" / "hand.xml"
INITIAL_MODEL = ROOT / "checkpoints" / "visual_grasp_ppo_v3.zip"
CHECKPOINT_DIR = ROOT / "checkpoints"
LOG_DIR = ROOT / "logs" / "visual_grasp_v32_finetune"
TOTAL_TIMESTEPS = 50_000


def make_env():
    def _init():
        env = VisualGraspEnvV32(
            model_path=str(XML_PATH),
            frame_skip=10,
            max_episode_steps=300,
            image_size=84,
        )
        return Monitor(env, info_keywords=("is_success", "contact_count"))
    return _init


def main():
    if not XML_PATH.is_file():
        raise FileNotFoundError(f"Missing hand model: {XML_PATH}")
    if not INITIAL_MODEL.is_file():
        raise FileNotFoundError(
            f"Missing V3 starting checkpoint: {INITIAL_MODEL}\n"
            "This fine-tuning run needs the V3 model that previously made "
            "index/middle/little/thumb contact. Do not substitute the collapsed V3.2 checkpoint."
        )

    CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    vec_env = VecMonitor(DummyVecEnv([make_env()]))
    callback = CheckpointCallback(
        save_freq=25_000,
        save_path=str(CHECKPOINT_DIR),
        name_prefix="visual_grasp_v32_finetune",
        save_replay_buffer=False,
        save_vecnormalize=False,
    )

    model = None
    try:
        # Observation/action spaces are intentionally unchanged between V3 and
        # V3.2: both use RGB+depth and five finger-closure actions.
        model = RecurrentPPO.load(
            str(INITIAL_MODEL), env=vec_env, device="auto"
        )
        # Lower the V3 learning rate for careful adaptation to the V3.2 reward.
        model.learning_rate = 5.0e-5
        model.lr_schedule = lambda _progress_remaining: 5.0e-5
        model.ent_coef = 0.035
        model.tensorboard_log = str(LOG_DIR)
        model.verbose = 1

        print(f"Warm-start checkpoint: {INITIAL_MODEL}")
        print("Starting V3.2 reward fine-tuning; V3.2-from-scratch weights are not used.")
        model.learn(
            total_timesteps=TOTAL_TIMESTEPS,
            callback=callback,
            log_interval=1,
            reset_num_timesteps=False,
            progress_bar=False,
        )
        final_path = CHECKPOINT_DIR / "visual_grasp_ppo_v32_finetuned"
        model.save(str(final_path))
        print(f"\nSaved final model: {final_path}.zip")
    finally:
        vec_env.close()


if __name__ == "__main__":
    main()
