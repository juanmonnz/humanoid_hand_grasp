V3 -> V3.2 REWARD FINE-TUNING

Why this run is different
-------------------------
The V3 policy is the only saved policy so far that visibly demonstrated
contacts on index, middle, little and thumb. V3.1/V3.2-from-scratch repeatedly
collapsed to thumb-only action with no contacts. This package therefore
warm-starts from the V3 weights and adapts them to the V3.2 reward instead of
starting a new policy from random initialization.

Requirements in the project root
--------------------------------
- models/hand.xml
- rl/grasp_env_v32.py
- checkpoints/visual_grasp_ppo_v3.zip
- installed MuJoCo, Gymnasium, Stable-Baselines3, sb3-contrib, OpenCV, PyTorch

Install
-------
Extract this ZIP into the robotic_grasp_upgrade project root, merging the rl
folder. It only adds two files and does not overwrite the XML or checkpoints.

Run training from the project root:
  C:\Python313\python.exe -m rl.train_v32_finetune

It fine-tunes for 250,000 timesteps and saves checkpoints every 25,000 steps.
Final model:
  checkpoints\visual_grasp_ppo_v32_finetuned.zip

Evaluate:
  C:\Python313\python.exe -m rl.evaluate_v32_finetune

The evaluator saves:
  results\visual_grasp_v32_finetuned.mp4

The policy sees RGB and depth only. Contact and object physics are used only
inside the environment's reward and evaluation metrics. This is a more
informed next attempt, not a guarantee of successful grasping.
