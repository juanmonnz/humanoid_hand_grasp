import time
import argparse
import mujoco
import mujoco.viewer
from stable_baselines3 import PPO

from grasp_env_v1 import GraspEnvV1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", required=True)
    parser.add_argument("--delay", type=float, default=0.03)
    args = parser.parse_args()

    # One physics step per environment step
    env = GraspEnvV1(frame_skip=1)
    model = PPO.load(args.model)

    obs, info = env.reset()

    print("Starting slow-motion visualization...")
    print("Close the viewer window to stop.")

    with mujoco.viewer.launch_passive(
        env.model, env.data
    ) as viewer:

        while viewer.is_running():
            action, _ = model.predict(
                obs, deterministic=True
            )

            obs, reward, terminated, truncated, info = env.step(action)

            viewer.sync()
            time.sleep(args.delay)

            if terminated or truncated:
                obs, info = env.reset()


if __name__ == "__main__":
    main()