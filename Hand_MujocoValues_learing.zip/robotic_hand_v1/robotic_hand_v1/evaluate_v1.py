"""Evaluate a trained V1 PPO model with an optional MuJoCo viewer."""
from __future__ import annotations

import argparse
import numpy as np
import mujoco
import mujoco.viewer
from stable_baselines3 import PPO

from grasp_env_v1 import GraspEnvV1


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate robotic hand V1")
    parser.add_argument("--xml", default="hand.xml")
    parser.add_argument("--model", default="models_v1/grasp_v1_final.zip")
    parser.add_argument("--episodes", type=int, default=5)
    parser.add_argument("--object-body", default=None)
    args = parser.parse_args()

    env = GraspEnvV1(args.xml, object_body_name=args.object_body)
    model = PPO.load(args.model, device="auto")
    successes = 0
    attempts = 0

    with mujoco.viewer.launch_passive(env.model, env.data) as viewer:
        for episode in range(args.episodes):
            obs, info = env.reset(seed=episode)
            terminated = truncated = False
            total_reward = 0.0
            last_info = {}
            while viewer.is_running() and not (terminated or truncated):
                action, _ = model.predict(obs, deterministic=True)
                obs, reward, terminated, truncated, last_info = env.step(action)
                total_reward += reward
                viewer.sync()

            attempts += 1
            success = bool(last_info.get("success", False))
            successes += int(success)
            print(
                f"episode={episode + 1} success={success} "
                f"contacts={last_info.get('contact_fingers', ())} "
                f"lift={last_info.get('lift_height', 0.0):.4f} "
                f"stable_steps={last_info.get('stable_steps', 0)} "
                f"reward={total_reward:+.2f}"
            )
            if not viewer.is_running():
                break

    env.close()
    if attempts:
        print(f"Success rate: {100.0 * successes / attempts:.1f}% ({successes}/{attempts})")


if __name__ == "__main__":
    main()
