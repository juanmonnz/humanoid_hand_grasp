"""Check that MuJoCo can load the XML and the V1 environment can step."""
from grasp_env_v1 import GraspEnvV1
import numpy as np


def main() -> None:
    env = GraspEnvV1("hand.xml")
    obs, info = env.reset(seed=1)
    print("MuJoCo model loaded")
    print("Object:", info["object_body"])
    print("Observation shape:", obs.shape)
    print("Action shape:", env.action_space.shape)
    for step in range(5):
        action = np.full(5, 0.15 + 0.1 * step, dtype=np.float32)
        obs, reward, terminated, truncated, info = env.step(action)
        print(
            f"step={step + 1} reward={reward:+.3f} "
            f"contacts={info['contact_fingers']} "
            f"lift={info['lift_height']:.4f} "
            f"success={info['success']}"
        )
        if terminated or truncated:
            break
    env.close()
    print("Smoke test completed")


if __name__ == "__main__":
    main()
