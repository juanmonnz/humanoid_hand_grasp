"""Simple state-based MuJoCo grasp environment for robotic_five_finger_hand_v2 with coupled finger movement."""
from __future__ import annotations

from typing import Dict, List, Optional, Set, Tuple
import os

import gymnasium as gym
from gymnasium import spaces
import mujoco
import numpy as np

FINGERS = ("thumb", "index", "middle", "ring", "little")
PART_ORDER = {"mcp": 0, "pip": 1, "dip": 2}
CURL_RATIOS = {"mcp": 1.00, "pip": 0.90, "dip": 0.80}


def _name(model: mujoco.MjModel, obj_type: mujoco.mjtObj, idx: int) -> str:
    value = mujoco.mj_id2name(model, obj_type, int(idx))
    return value or f"unnamed_{int(idx)}"


class GraspEnvV1(gym.Env):
    """Gymnasium environment for five-finger robotic hand grasping with synchronized finger joints."""

    metadata = {"render_modes": ["human", "rgb_array"]}

    def __init__(
        self,
        model_path: str = "hand.xml",
        object_body_name: Optional[str] = None,
        frame_skip: int = 10,
        max_episode_steps: int = 250,
        stable_steps_required: int = 20,
        min_lift: Optional[float] = None,
        object_xy_noise: float = 0.0,
        require_thumb: bool = False,
        min_contact_fingers: int = 3,
        action_smoothing: float = 0.3,
    ):
        super().__init__()
        if not os.path.isfile(model_path):
            raise FileNotFoundError(f"MuJoCo XML not found: {model_path}")

        self.model_path = os.path.abspath(model_path)
        self.model = mujoco.MjModel.from_xml_path(self.model_path)
        self.data = mujoco.MjData(self.model)
        self.frame_skip = max(1, int(frame_skip))
        self.max_episode_steps = max(1, int(max_episode_steps))
        self.stable_steps_required = max(1, int(stable_steps_required))
        self.requested_min_lift = min_lift
        self.object_xy_noise = max(0.0, float(object_xy_noise))
        self.require_thumb = bool(require_thumb)
        self.min_contact_fingers = max(1, min(5, int(min_contact_fingers)))
        self.action_smoothing = float(np.clip(action_smoothing, 0.0, 1.0))

        # Identify hand base and target object body
        self.hand_base_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_BODY, "hand_base")
        
        target_name = object_body_name if object_body_name else "test_block"
        self.object_body_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_BODY, target_name)
        self.object_body_name = target_name
        
        if self.hand_base_id < 0 or self.object_body_id < 0:
            raise ValueError(f"Could not find 'hand_base' or target object body '{target_name}' in XML.")

        # Find object freejoint
        obj_jnt_id = -1
        for j in range(self.model.njnt):
            if int(self.model.jnt_type[j]) == int(mujoco.mjtJoint.mjJNT_FREE):
                if int(self.model.jnt_bodyid[j]) == self.object_body_id:
                    obj_jnt_id = j
                    break
        if obj_jnt_id < 0:
            raise ValueError(f"Object body '{target_name}' requires a free joint.")

        self.object_qpos_adr = int(self.model.jnt_qposadr[obj_jnt_id])
        self.object_dof_adr = int(self.model.jnt_dofadr[obj_jnt_id])

        # Object collision geoms
        self.object_geom_ids = [
            g for g in range(self.model.ngeom)
            if self._is_descendant(int(self.model.geom_bodyid[g]), self.object_body_id)
        ]

        # Map joints and actuators per finger
        self._find_hand_and_fingers()

        # Spaces: 15 joint positions + 15 velocities + 3 rel_pos + 4 quat + 6 obj_vel + 5 dists + 5 contacts + 5 prev_actions = 58 dim
        obs_dim = 15 + 15 + 3 + 4 + 6 + 5 + 5 + 5
        self.observation_space = spaces.Box(low=-np.inf, high=np.inf, shape=(obs_dim,), dtype=np.float32)
        # Action space is 5 (one closure value per finger, controlling MCP, PIP, and DIP simultaneously)
        self.action_space = spaces.Box(low=0.0, high=1.0, shape=(5,), dtype=np.float32)

        mujoco.mj_resetData(self.model, self.data)
        mujoco.mj_forward(self.model, self.data)
        self.base_object_qpos = self.data.qpos[self.object_qpos_adr:self.object_qpos_adr + 7].copy()
        self.object_start_pos = self.data.xpos[self.object_body_id].copy()

        if self.requested_min_lift is None:
            radius = max(float(self.model.geom_rbound[g]) for g in self.object_geom_ids) if self.object_geom_ids else 0.02
            self.min_lift = float(np.clip(radius * 0.25, 0.005, 0.020))
        else:
            self.min_lift = max(0.001, float(self.requested_min_lift))

        self.episode_steps = 0
        self.stable_steps = 0
        self.last_action = np.zeros(5, dtype=np.float32)
        self.previous_lift_height = 0.0

    def _is_descendant(self, body_id: int, root_id: int) -> bool:
        curr = body_id
        while curr > 0:
            if curr == root_id:
                return True
            curr = int(self.model.body_parentid[curr])
        return curr == root_id

    def _find_hand_and_fingers(self) -> None:
        self.joint_ids: Dict[str, List[int]] = {f: [] for f in FINGERS}
        self.actuators: Dict[str, List[Tuple[int, int, str]]] = {f: [] for f in FINGERS}
        joint_type_hinge = int(mujoco.mjtJoint.mjJNT_HINGE)

        for jid in range(self.model.njnt):
            jname = _name(self.model, mujoco.mjtObj.mjOBJ_JOINT, jid).lower()
            if int(self.model.jnt_type[jid]) != joint_type_hinge:
                continue
            for finger in FINGERS:
                if finger in jname and any(part in jname for part in PART_ORDER):
                    self.joint_ids[finger].append(jid)
                    break

        for finger in FINGERS:
            ids = sorted(
                self.joint_ids[finger],
                key=lambda j: next(
                    (order for part, order in PART_ORDER.items()
                     if part in _name(self.model, mujoco.mjtObj.mjOBJ_JOINT, j).lower()),
                    99,
                ),
            )
            self.joint_ids[finger] = ids

            for jid in ids:
                jname = _name(self.model, mujoco.mjtObj.mjOBJ_JOINT, jid).lower()
                part = next((p for p in PART_ORDER if p in jname), "mcp")
                for aid in range(self.model.nu):
                    if int(self.model.actuator_trnid[aid, 0]) == jid:
                        self.actuators[finger].append((aid, jid, part))

        # Finger collision geoms mapping
        self.finger_geom_ids: Dict[str, Set[int]] = {f: set() for f in FINGERS}
        for gid in range(self.model.ngeom):
            body_id = int(self.model.geom_bodyid[gid])
            body_name = mujoco.mj_id2name(self.model, mujoco.mjtObj.mjOBJ_BODY, body_id) or ""
            for f in FINGERS:
                if f in body_name.lower():
                    self.finger_geom_ids[f].add(gid)

    def _set_action(self, action: np.ndarray) -> None:
        action = np.asarray(action, dtype=np.float32).reshape(5)
        action = np.clip(action, 0.0, 1.0)

        # Smooth action transitions across the 5 fingers
        filtered_action = self.action_smoothing * self.last_action + (1.0 - self.action_smoothing) * action
        self.last_action = filtered_action.copy()

        for finger_index, finger in enumerate(FINGERS):
            closure = float(filtered_action[finger_index])
            for actuator_id, joint_id, part in self.actuators[finger]:
                joint_lo, joint_hi = map(float, self.model.jnt_range[joint_id])
                ratio = CURL_RATIOS.get(part, 1.0)
                target = joint_lo + (joint_hi - joint_lo) * closure * ratio
                if bool(self.model.actuator_ctrllimited[actuator_id]):
                    ctrl_lo, ctrl_hi = map(float, self.model.actuator_ctrlrange[actuator_id])
                    target = float(np.clip(target, ctrl_lo, ctrl_hi))
                self.data.ctrl[actuator_id] = target

    def _geom_distance(self, geom_a: int, geom_b: int) -> float:
        if hasattr(mujoco, "mj_geomDistance"):
            segment = np.zeros(6, dtype=np.float64)
            try:
                d = float(mujoco.mj_geomDistance(self.model, self.data, geom_a, geom_b, 0.3, segment))
                if np.isfinite(d):
                    return max(0.0, d)
            except Exception:
                pass
        dist = np.linalg.norm(self.data.geom_xpos[geom_a] - self.data.geom_xpos[geom_b])
        return max(0.0, dist - self.model.geom_rbound[geom_a] - self.model.geom_rbound[geom_b])

    def _get_finger_distances(self) -> Dict[str, float]:
        dists = {}
        for f in FINGERS:
            min_d = 0.25
            for fg in self.finger_geom_ids[f]:
                for og in self.object_geom_ids:
                    min_d = min(min_d, self._geom_distance(fg, og))
            dists[f] = float(min_d)
        return dists

    def _get_contacts(self) -> Set[str]:
        contacts = set()
        obj_geoms = set(self.object_geom_ids)
        for i in range(self.data.ncon):
            c = self.data.contact[i]
            if float(c.dist) > 0.003:
                continue
            g1, g2 = int(c.geom1), int(c.geom2)
            hand_geom = g2 if g1 in obj_geoms else (g1 if g2 in obj_geoms else None)
            if hand_geom is not None:
                for f in FINGERS:
                    if hand_geom in self.finger_geom_ids[f]:
                        contacts.add(f)
        return contacts

    def _get_obs(self) -> np.ndarray:
        joint_pos, joint_vel = [], []
        for i in range(self.model.njnt):
            if int(self.model.jnt_type[i]) == int(mujoco.mjtJoint.mjJNT_HINGE):
                qadr = int(self.model.jnt_qposadr[i])
                dadr = int(self.model.jnt_dofadr[i])
                lo, hi = self.model.jnt_range[i]
                q = float(self.data.qpos[qadr])
                q_norm = 2.0 * (q - lo) / max(hi - lo, 1e-6) - 1.0
                joint_pos.append(q_norm)
                joint_vel.append(float(self.data.qvel[dadr]) / 10.0)

        obj_pos = self.data.xpos[self.object_body_id].copy()
        hand_pos = self.data.xpos[self.hand_base_id].copy()
        rel_pos = (obj_pos - hand_pos) / 0.3

        quat = self.data.qpos[self.object_qpos_adr + 3:self.object_qpos_adr + 7].copy()
        lin_vel = self.data.qvel[self.object_dof_adr:self.object_dof_adr + 3] / 2.0
        ang_vel = self.data.qvel[self.object_dof_adr + 3:self.object_dof_adr + 6] / 4.0

        dists = self._get_finger_distances()
        dist_vals = np.array([dists[f] / 0.25 for f in FINGERS], dtype=np.float32)
        contacts = self._get_contacts()
        contact_vals = np.array([1.0 if f in contacts else 0.0 for f in FINGERS], dtype=np.float32)

        obs = np.concatenate([
            np.asarray(joint_pos, dtype=np.float32),
            np.asarray(joint_vel, dtype=np.float32),
            rel_pos.astype(np.float32),
            quat.astype(np.float32),
            lin_vel.astype(np.float32),
            ang_vel.astype(np.float32),
            dist_vals,
            contact_vals,
            self.last_action.astype(np.float32),
        ])
        return obs.astype(np.float32)

    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)
        mujoco.mj_resetData(self.model, self.data)
        
        self.data.qpos[self.object_qpos_adr:self.object_qpos_adr + 7] = self.base_object_qpos
        self.data.qvel[self.object_dof_adr:self.object_dof_adr + 6] = 0.0

        if self.object_xy_noise > 0:
            self.data.qpos[self.object_qpos_adr] += self.np_random.uniform(-self.object_xy_noise, self.object_xy_noise)
            self.data.qpos[self.object_qpos_adr + 1] += self.np_random.uniform(-self.object_xy_noise, self.object_xy_noise)

        # Set actuators to minimum control range
        for aid in range(self.model.nu):
            ctrl_range = self.model.actuator_ctrlrange[aid]
            self.data.ctrl[aid] = ctrl_range[0]

        mujoco.mj_forward(self.model, self.data)
        self.object_start_pos = self.data.xpos[self.object_body_id].copy()
        self.episode_steps = 0
        self.stable_steps = 0
        self.last_action[:] = 0.0
        self.previous_lift_height = 0.0

        return self._get_obs(), {"object_body": self.object_body_name}

    def step(self, action):
        self._set_action(action)

        for _ in range(self.frame_skip):
            mujoco.mj_step(self.model, self.data)

        self.episode_steps += 1
        contacts = self._get_contacts()
        dists = self._get_finger_distances()  # <-- Add this line back

        # Reward formulation
        mean_dist = float(np.mean(list(dists.values())))
        reward = 0.5 * (0.25 - min(mean_dist, 0.25))

        contact_count = len(contacts)
        thumb_contact = "thumb" in contacts
        if contact_count > 0:
            # Base contact scaling
            reward += 3.0 * (contact_count ** 2.0)
            
            if contact_count >= 3:
                reward += 10.0
                
            # EXTRA BONUS: Massive reward boost when all 5 fingers touch simultaneously
            if contact_count == 5:
                reward += 75.0  # Big extra points for a complete 5-finger wrap!
                
            if thumb_contact:
                reward += 5.0

        coordinated = (
            contact_count >= self.min_contact_fingers
            and (thumb_contact or not self.require_thumb)
        )

        obj_pos = self.data.xpos[self.object_body_id].copy()
        lift_height = float(obj_pos[2] - self.object_start_pos[2])
        lift_delta = max(0.0, lift_height - self.previous_lift_height)
        
        if coordinated and lift_delta > 0.0:
            reward += (1000.0 / 600.0) * lift_delta

        self.previous_lift_height = lift_height

        # Penalize jerky joint velocities during contact to prevent twitching/chattering
        joint_velocities = []
        for i in range(self.model.njnt):
            if int(self.model.jnt_type[i]) == int(mujoco.mjtJoint.mjJNT_HINGE):
                dadr = int(self.model.jnt_dofadr[i])
                joint_velocities.append(abs(float(self.data.qvel[dadr])))
        mean_joint_vel = np.mean(joint_velocities) if joint_velocities else 0.0
        
        if contact_count > 0:
            reward -= 0.5 * mean_joint_vel

        success = lift_height >= self.min_lift and coordinated
        terminated = False
        truncated = self.episode_steps >= self.max_episode_steps

        if success:
            reward += 100.0
            terminated = True

        obj_fell = obj_pos[2] < (self.object_start_pos[2] - 0.03)
        if obj_fell and not success:
            reward -= 15.0
            terminated = True

        info = {
            "success": success,
            "contact_count": contact_count,
            "lift_height": lift_height,
        }
        return self._get_obs(), float(reward), terminated, truncated, info

    def render(self):
        pass

    def close(self):
        pass