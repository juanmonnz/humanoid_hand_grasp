"""Diagnostic evaluator for V1: reports episode history and reward components."""
from __future__ import annotations

import argparse
import numpy as np
import mujoco
import mujoco.viewer
from stable_baselines3 import PPO

from grasp_env_v1 import GraspEnvV1

FINGERS = ("thumb", "index", "middle", "ring", "little")
WEIGHTS = {"thumb": 1.5, "index": 1.0, "middle": 1.0, "ring": 1.0, "little": 1.0}


def main() -> None:
    parser = argparse.ArgumentParser(description="Diagnostic evaluation for robotic hand V1")
    parser.add_argument("--xml", default="hand.xml")
    parser.add_argument("--model", default="models_v1/grasp_v1_final.zip")
    parser.add_argument("--episodes", type=int, default=3)
    parser.add_argument("--object-body", default=None)
    parser.add_argument("--sample-every", type=int, default=25)
    args = parser.parse_args()

    env = GraspEnvV1(args.xml, object_body_name=args.object_body)
    model = PPO.load(args.model, device="auto")
    print(f"Object: {env.object_body_name}")
    print(f"Minimum lift required: {env.min_lift:.4f} m")
    print(f"Object XY randomization: {env.object_xy_noise:.4f} m")
    if env.object_xy_noise == 0:
        print("NOTE: Every evaluation episode starts at the same object position.")

    successes = 0
    attempts = 0

    with mujoco.viewer.launch_passive(env.model, env.data) as viewer:
        for episode in range(args.episodes):
            obs, reset_info = env.reset(seed=episode)
            terminated = truncated = False
            total_reward = 0.0
            steps = 0
            last_info = {}
            contacts_seen = set()
            max_contact_count = 0
            max_lift = -float("inf")
            max_lift_step = 0
            max_stable_steps = 0
            action_sum = np.zeros(5, dtype=np.float64)
            potential_values = []
            reward_parts = {
                "potential_progress": 0.0,
                "proximity": 0.0,
                "new_contacts": 0.0,
                "maintained_contacts": 0.0,
                "coordination": 0.0,
                "lifting": 0.0,
                "velocity_penalty": 0.0,
                "stability": 0.0,
                "smoothness_penalty": 0.0,
                "success_bonus": 0.0,
                "fall_penalty": 0.0,
                "horizontal_push_penalty": 0.0,
                "timeout_penalty": 0.0,
            }
            previous_potential = float(env.previous_potential)
            previously_contacted = set()
            previous_action = np.zeros(5, dtype=np.float32)
            last_printed_lift = -float("inf")

            print(f"\n===== EPISODE {episode + 1} =====")
            print(f"Reset info: {reset_info}")

            while viewer.is_running() and not (terminated or truncated):
                action, _ = model.predict(obs, deterministic=True)
                action = np.asarray(action, dtype=np.float32).reshape(5)
                obs, reward, terminated, truncated, info = env.step(action)
                viewer.sync()

                steps += 1
                total_reward += float(reward)
                action_sum += action
                contacts = set(info.get("contact_fingers", ()))
                contacts_seen.update(contacts)
                max_contact_count = max(max_contact_count, len(contacts))
                lift = float(info.get("lift_height", 0.0))
                if lift > max_lift:
                    max_lift = lift
                    max_lift_step = steps
                max_stable_steps = max(max_stable_steps, int(info.get("stable_steps", 0)))

                distances = info.get("finger_distances", {})
                potential = float(sum(
                    WEIGHTS[f] * np.exp(-float(distances.get(f, 0.25)) / 0.055)
                    for f in FINGERS
                ))
                potential_values.append(potential)
                potential_delta = float(np.clip(potential - previous_potential, -1.0, 1.0))
                reward_parts["potential_progress"] += 2.0 * potential_delta
                reward_parts["proximity"] += 0.05 * potential

                new_contacts = contacts - previously_contacted
                reward_parts["new_contacts"] += float(len(new_contacts))
                reward_parts["maintained_contacts"] += 0.08 * len(contacts)

                thumb_contact = "thumb" in contacts
                other_count = sum(f in contacts for f in FINGERS if f != "thumb")
                coordinated = bool(info.get("coordinated_contact", False))
                if coordinated:
                    reward_parts["coordination"] += 1.0
                elif thumb_contact and other_count >= 1:
                    reward_parts["coordination"] += 0.35

                min_lift = max(float(info.get("minimum_lift", env.min_lift)), 0.001)
                reward_parts["lifting"] += 2.0 * min(max(lift, 0.0) / min_lift, 1.0)

                linear_speed = float(info.get("object_linear_speed", 0.0))
                angular_speed = float(info.get("object_angular_speed", 0.0))
                if contacts:
                    reward_parts["velocity_penalty"] -= (
                        0.10 * min(linear_speed, 2.0)
                        + 0.025 * min(angular_speed, 4.0)
                    )

                if int(info.get("stable_steps", 0)) > 0:
                    reward_parts["stability"] += 0.35

                reward_parts["smoothness_penalty"] -= 0.01 * float(
                    np.mean(np.abs(action - previous_action))
                )

                if bool(info.get("success", False)):
                    reward_parts["success_bonus"] += 25.0

                horizontal = float(info.get("horizontal_displacement", 0.0))
                if horizontal > 0.15 and lift < min_lift:
                    reward_parts["horizontal_push_penalty"] -= 2.0

                fell = lift < -max(0.04, 2.0 * env.min_lift)
                if fell and not bool(info.get("success", False)):
                    reward_parts["fall_penalty"] -= 10.0

                if truncated and not bool(info.get("success", False)):
                    reward_parts["timeout_penalty"] -= 2.0

                if (steps == 1 or steps % max(1, args.sample_every) == 0
                        or contacts != set(last_info.get("contact_fingers", ()))
                        or lift > last_printed_lift + 0.001):
                    last_printed_lift = max(last_printed_lift, lift)
                    print(
                        f"step={steps:03d} action={np.round(action, 2).tolist()} "
                        f"contacts={tuple(sorted(contacts))} "
                        f"lift={lift:+.4f}m horiz={horizontal:.4f}m "
                        f"stable={info.get('stable_steps', 0)} "
                        f"dist={{{', '.join(f'{k}:{v:.3f}' for k, v in distances.items())}}} "
                        f"reward={float(reward):+.3f}"
                    )

                previous_potential = potential
                previously_contacted.update(contacts)
                previous_action = action.copy()
                last_info = info

            attempts += 1
            success = bool(last_info.get("success", False))
            successes += int(success)
            avg_action = action_sum / max(steps, 1)
            reconstructed = sum(reward_parts.values())

            print("--- EPISODE SUMMARY ---")
            print(f"success={success}; steps={steps}; total_reward={total_reward:+.3f}")
            print(f"contacts_seen_during_episode={tuple(sorted(contacts_seen))}")
            print(f"final_step_contacts={last_info.get('contact_fingers', ())}")
            print(f"max_contact_count={max_contact_count}")
            print(f"max_lift={max_lift:+.4f} m at step {max_lift_step}")
            print(f"final_lift={last_info.get('lift_height', 0.0):+.4f} m")
            print(f"max_stable_steps={max_stable_steps}")
            print(f"mean_actions thumb/index/middle/ring/little={np.round(avg_action, 3).tolist()}")
            if potential_values:
                print(
                    f"potential min/mean/max={min(potential_values):.3f}/"
                    f"{np.mean(potential_values):.3f}/{max(potential_values):.3f}"
                )
            print("reward breakdown:")
            for name, value in reward_parts.items():
                print(f"  {name}: {value:+.3f}")
            print(f"reconstructed_reward={reconstructed:+.3f}; difference={total_reward-reconstructed:+.5f}")

            if not viewer.is_running():
                break

    env.close()
    if attempts:
        print(f"\nDiagnostic success rate: {100.0 * successes / attempts:.1f}% ({successes}/{attempts})")


if __name__ == "__main__":
    main()
