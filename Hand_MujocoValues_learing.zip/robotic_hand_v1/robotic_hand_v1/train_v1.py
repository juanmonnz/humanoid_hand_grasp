"""Train a simple state-based PPO policy for the supplied MuJoCo hand."""
from __future__ import annotations

import argparse
import os

from stable_baselines3 import PPO
from stable_baselines3.common.callbacks import CheckpointCallback
from stable_baselines3.common.monitor import Monitor

from grasp_env_v1 import GraspEnvV1


def main() -> None:
    parser = argparse.ArgumentParser(description="Train MuJoCo robotic hand V1")
    parser.add_argument("--xml", default="hand.xml", help="Path to MJCF XML")
    parser.add_argument("--steps", type=int, default=300_000, help="Training timesteps")
    parser.add_argument("--object-body", default=None, help="Optional target body or freejoint name")
    parser.add_argument("--min-lift", type=float, default=None, help="Success lift threshold in metres")
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--output", default="models_v1")
    args = parser.parse_args()

    os.makedirs(args.output, exist_ok=True)
    env = Monitor(GraspEnvV1(
        model_path=args.xml,
        object_body_name=args.object_body,
        min_lift=args.min_lift,
        frame_skip=10,
        max_episode_steps=250,
    ))

    checkpoint = CheckpointCallback(
        save_freq=25_000,
        save_path=args.output,
        name_prefix="grasp_v1_checkpoint",
    )

    # V1 deliberately uses standard PPO with an MLP over MuJoCo state values.
    model = PPO(
        policy="MlpPolicy",
        env=env,
        learning_rate=3e-4,
        n_steps=1024,
        batch_size=64,
        gamma=0.99,
        gae_lambda=0.95,
        clip_range=0.2,
        ent_coef=0.0,
        verbose=1,
        seed=args.seed,
        tensorboard_log=os.path.join(args.output, "tensorboard"),
        device="auto",
    )

    print("Starting V1 state-based training")
    print("Observation: MuJoCo joint/object/contact state")
    print("Actions: 5 finger closure commands")
    print(f"Target object: {env.unwrapped.object_body_name}")
    model.learn(
        total_timesteps=args.steps,
        callback=checkpoint,
        progress_bar=False,
    )
    final_path = os.path.join(args.output, "grasp_v1_final")
    model.save(final_path)
    env.close()
    print(f"Training complete. Model saved to {final_path}.zip")


if __name__ == "__main__":
    main()
